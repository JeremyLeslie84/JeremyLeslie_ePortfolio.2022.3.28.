/*
Establishes connection path.
Loads external libraries express, handlebars, and express handlebars.
Opens socket on local host port 3000.
*/
require('./models/db')

// Import express module.
const express = require('express');
// Create path object for IP.
const path = require("path");
// Import handlebars module.
const handlebars = require("handlebars");
// Import express handlebars module.
const {engine} = require("express-handlebars");
const {allowInsecurePrototypeAccess} = require("@handlebars/allow-prototype-access");
const bodyparser = require("body-parser");
// Import controller module.
const animalController = require('./controllers/animalController');

// Create express object for app framework.
var app = express();
app.use(bodyparser.urlencoded({extended: false}));
app.use(bodyparser.json());

// Set the path to callback.
app.get('/', (req, res) => {
    res.send('<h2>Welcome to Animals Database!!</h2><h3>Click here to get access to the <b> <a href="/animal/list">Database</a></b></h3>');
});

// set the express path name.
app.set("views", path.join(__dirname,"/views/"));

// Initialize the app framework and set the view.
app.engine('hbs', engine({
    handlebars: allowInsecurePrototypeAccess(handlebars),
    extname: 'hbs',
    defaultLayout: "MainLayout",
    layoutsDir: __dirname + "/views/layouts/"
}));

// Set the view engine to handlebars.
app.set("view engine", "hbs");
// Initatie listening on port 3000.
app.listen(3000, () => {
    console.log("Express server started at port 3000");
});

app.use('/animal', animalController);



