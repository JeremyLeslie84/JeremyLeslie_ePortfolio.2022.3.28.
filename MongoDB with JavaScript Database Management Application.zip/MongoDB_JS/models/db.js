/*
Establish connection to database using mongoose driver.
*/

// Import mongodb mongoose library.
const mongoose = require('mongoose')

// Set the connection path for the mongoose object.
mongoose.connect("mongodb://localhost:27017/aac_shelter_outcomes", {
    useNewUrlParser: true
},
err=> {
    // If connection succeeds print success message to console.
    if (!err){
        console.log('Connection successful')
    }
    // If connection fails print error message to console.
    else {
        console.log('Error in connection' + err)
    }
})

require('./animal.model')