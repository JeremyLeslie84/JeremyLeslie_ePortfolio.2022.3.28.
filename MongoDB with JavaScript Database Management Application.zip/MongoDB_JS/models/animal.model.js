/*
Animal object database schema.
*/

// Import mongodb mongoose module.
const mongoose = require('mongoose')

// Create new schema object and define object variables.
var animalSchema = new mongoose.Schema({
    animal_id: {
        type: String,
        require: 'This field is required'
    },
    animal_type: {
        type: String,
        required: 'This field is required'
    },
    age_upon_outcome: {
        type: String,
        require: 'This field is required'
    },
    breed: {
        type: String,
        required: 'This field is required'
    },
})

mongoose.model('Animal',animalSchema);