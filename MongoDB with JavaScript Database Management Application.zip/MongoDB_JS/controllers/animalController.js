/*
Animal controller.
Main control class for MongoDB CRUD operations.
Uses express web application framework.
*/

// Import express module.
const express = require('express')
// Create express router object to handle database requests.
var router = express.Router()
// Import mongodb mongoose module.
const mongoose = require('mongoose')
// Create animal schema wrapper.
const Animal = mongoose.model('Animal')

// Route handler executed when the create new button is clicked from the animal list view.
// Renders the animal addOrEdit view and sets view title.
router.get('/', (req, res)=>{
    // Render the addOrEdit view.
    res.render('animal/addOrEdit', {
        // Set the view title.
        viewTitle: 'Insert Animal'
    })
})

// Route handler executed when findByID button is clicked from the animal list view. 
// Renders the animal find view and sets view title.
router.get('/find', (req, res)=>{
    // Render the find view.
    res.render('animal/find', {
        // Set the view title.
        viewTitle: 'Find Animal By ID'
    })
})

// Route handler executed when submit button is clicked from the find view. 
// Queries database using animal_id, renders the animal list view, and prints the returned documents.
router.get('/findByID', (req, res) => {
    // Query database for matching entries using animal_id.
    Animal.find({animal_id : req.body.animal_id}, (err, doc) => {
        // If query succeeds render list view and print returned documents.
        if (!err) {
            res.render('animal/list', {
                list: doc
            });
        }
        // If query fails print error message to console.
        else {
            
            console.log(doc);
        }
    });
});

// Route handler executes when the submit button is clicked from the addOrEdit view.
router.post('/', (req, res) => {
    // If the id is null create a new record.
    if (req.body._id == '') {
        insertRecord(req,res)
    }
    // If the id is not null update record matching id.
    else {
        updateRecord(req,res)
    }
})

// Function to insert a new record.
function insertRecord(req, res) {
    // Create new animal object.
    var animal = new Animal()
    // Set animal variables.
    animal.animal_id = req.body.animal_id;
    animal.animal_type = req.body.animal_type;
    animal.age_upon_outcome = req.body.age_upon_outcome;
    animal.breed = req.body.breed;
    // Save database.
    animal.save((err, doc) => {
        // If save succeeds redirect route handler path to /list.
        if (!err) {
            res.redirect('animal/list')
        }
        // If save fails print error message to console.
        else {
            console.log('Error during insert: ' + err)
        }
    })
}

// Function to update a record.
function updateRecord(req,res) {
    // Query database for mathcing entry using id.
    Animal.findOneAndUpdate({_id: req.body._id},
        req.body,
        {new: true},
        (err, doc) => {
            // If update succeeds redirect route handler path to /list.
            if (!err) {
                res.redirect('animal/list')
            }
            // If update fails print error message to console.
            else {
                console.log('Error during update: ' + err);
            }
        }
    );
}

// Route handler executes when the view all button is clicked from any view.
router.get('/list', (req, res) => {
    // Query database for all entries.
    Animal.find((err, docs) => {
        // If query succeeds render the animal list view.
        if (!err) {
            res.render('animal/list', {
                list: docs
            })
        }
        // If query fails print error message to console.
        else {
            console.log('Error in retrieval: ' + err)
        }
    });
});

// Route handler executes when the edit button is clicked from the list view.
router.get('/:id', (req, res) => {
    // Query database for matching entry using ID.
    Animal.findById(req.params.id, (err, doc) => {
        // If query is successful render the addOrEdit view, set the view title, and populate form data.
        if(!err) {
            res.render('animal/addOrEdit', {
                viewTitle: 'Update Animal',
                animal: doc,
            });
        }
        // If query fails print error message to console.
        else {
            console.log(doc);
        }
    });
});

// Find animal by id and remove from list.
router.get('/delete/:id', (req,res) => {
    // Query database for matching entry using ID and remove any matches.
    Animal.findByIdAndRemove(req.params.id, (err, doc) => {
        // If query is successful find all database entries.
        if (!err) {
            // Query database for all entries.
            Animal.find((err, docs) => {
                // If query is successful render the list view, and print all documents.
                if (!err) {
                    res.render('animal/list', {
                        list: docs
                    })
                }
                // If query fails print error message to console.
                else {
                    console.log('Error in retrieval: ' + err)
                }
            });
        }
        // If query fails print error message to console.
        else {
            console.log('Error in deletion: ' + err);
        }
    });
});

module.exports = router

