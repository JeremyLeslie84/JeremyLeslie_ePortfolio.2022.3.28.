/*
 * Grand Strand System - Appointment class.
 * Developed by Jeremy Leslie 11/15/21.
 * Appointment class implements:
 * -Appointment variables
 * -Setter and getter methods for the Contacts class.
 */
package AppointmentService;

import java.util.Date;  

public class Appointment {
	// Class variables.
	String appointmentID;
	Date appointmentDate;
	String appointmentDescription;
	String appointmentFirstName;
	String appointmentLastName;

	Date currentDate = new Date();
	
	// Appointment constructor.
	public Appointment(String appointmentID, Date appointmentDate, String appointmentDescription,
			String appointmentFirstName, String appointmentLastName) {
				
		// Check if appointment id meets input criteria, if not throw exception error.
		if (appointmentID == null || appointmentID.length() != 10 || !checkStringIsNumeric(appointmentID)) {	
			throw new IllegalArgumentException("Invalid ID");
		}

		// Check if date meets input criteria, if not throw exception error.
		if (appointmentDate == null || appointmentDate.before(currentDate)) {
			throw new IllegalArgumentException("Invalid date");
		}

		// Check if appointment description meets input criteria, if not throw exception.
		if (appointmentDescription == null || appointmentDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		
		// Check if contact first name meets input criteria, if not throw exception.
		if (appointmentFirstName == null || appointmentFirstName.length() > 20) {
			throw new IllegalArgumentException("Invalid description");
		}
		
		// Check if contact last name meets input criteria, if not throw exception.
		if (appointmentLastName == null || appointmentLastName.length() > 20) {
			throw new IllegalArgumentException("Invalid description");
		}
		
		// Set object variables.
		this.appointmentID = appointmentID;
		this.appointmentDate = appointmentDate;
		this.appointmentDescription = appointmentDescription;
		this.appointmentFirstName = appointmentFirstName;
		this.appointmentLastName = appointmentLastName;
	}

	// Setter methods for the appointment class.
	public void setAppointmentDate(Date appointmentDate) {
		//Source the current date.
		Date date = new Date();
		// Check if date meets input criteria, if not throw exception error.
		if (appointmentDate != null && appointmentDate.after(date)) {
			this.appointmentDate = appointmentDate;
		}
		else {
			throw new IllegalArgumentException("Invalid date");
		}
	}

	public void setAppointmentDescription(String appointmentDescription) {
		// Check if appointment description meets input criteria, if not throw exception.
		if(!appointmentDescription.isBlank() && appointmentDescription.length() <= 50) {
			this.appointmentDescription = appointmentDescription;
		}
		else {
			throw new IllegalArgumentException("Invalid description");
		}
	}

	public void setAppointmentFirstName(String appointmentFirstName) {
		// Check if contact first name meets input criteria, if not throw exception.
		if (!appointmentFirstName.isEmpty() && appointmentFirstName.length() <= 20)
		this.appointmentFirstName = appointmentFirstName;
	}
	
	public void setAppointmentLastName(String appointmentLastName) {
		// Check if contact last name meets input criteria, if not throw exception.
		if (!appointmentLastName.isEmpty() && appointmentLastName.length() <= 20)
		this.appointmentLastName = appointmentLastName;
	}
	
		
	// Getter methods for the appointment class.
	public String getAppointmentID() {
		return appointmentID;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	
	public String getAppointmentFirstName() {
		return appointmentFirstName;
	}
	
	public String getAppointmentLastName() {
		return appointmentLastName;
	}
	
	// Method checks string format. If it contains any non-numeric characters or spaces a number format exception will be thrown.
	private boolean checkStringIsNumeric(String checkString) {
		try {
			Long.parseLong(checkString);
			return true;
		} catch (NumberFormatException numberFormatException) {
			return false;
		}
	}
}
