/*
 * Grand Strand System - AppointmentService class.
 * Developed by Jeremy Leslie 11/15/21.
 * AppointmentService class implements:
 * -Appointments file import from .csv for.
 * -Appointments file export to .csv.
 * -CRUD functionality for the Appointments class.
 */
package AppointmentService;

import java.util.Date;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class AppointmentService {
	// Declare ArrayList to store appointments.
	ArrayList<Appointment> appointmentList = new ArrayList<>();

	// Method reads appointment list from csv file.
	public void readAppointmentsFromDisk() throws IOException, ParseException {
		// Define the path to the source file.
		Path pathToFile = Paths
				.get("C:\\Users\\Keebler21084\\git\\Grand Strand System\\Grand Strand System\\appointment_list.csv");
		// Create a buffer reader object to read file.
		BufferedReader bufferReader = Files.newBufferedReader(pathToFile);
		// Read the next line of the loaded file into the buffer.
		String line = bufferReader.readLine();
		// Index used to ignore the first line of the file (header).
		int index = 0;
		// Create simple date format object to convert date to string and apply format.
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		// Date object sources current date.
		Date appointmentDate = new Date();
		// Loop until next line is null.
		while (line != null) {
			// If the current line in the buffer is the header.
			if (index == 0) {
				index++;
				// Read the next line of the file into the buffer.
				line = bufferReader.readLine();
				// If the current line in the buffer is not the header.
			} else {
				// Create a string array to store parsed values from line using the comma as a
				// separator.
				String[] fileValues = line.split(",");
				// Convert date (string format) input from csv to date format.
				appointmentDate = simpleDateFormat.parse(fileValues[1]);
				// Create a new appointment object using fileValues array containing parsed file
				// values.
				Appointment appointment = new Appointment(fileValues[0].toUpperCase(), appointmentDate,
						fileValues[2].toUpperCase(), fileValues[3].toUpperCase(), fileValues[4].toUpperCase());
				// Add appointment to ArrayList.
				addAppointment(appointment);
				// Read the next line of the file into the buffer.
				line = bufferReader.readLine();
			}
		}
	}

	// Method saves appointment list as csv file.
	public void writeAppointmentsToDisk() throws IOException {
		// Create simple date format object to convert date to string and apply format.
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		// String variable to hold date as string for export.
		String appointmentDateString;
		// Create a new file.
		File file = new File("appointment_list.csv");
		// Create file writer and buffer writer objects to write file.
		FileWriter fileWriter = new FileWriter(file);
		BufferedWriter bufferWriter = new BufferedWriter(fileWriter);
		// Write header to file.
		bufferWriter.write("AppointmentID,Date,Description,FirstName,LastName");
		// Write a new line after the header.
		bufferWriter.newLine();
		// Writer each appointment in array list to file.
		for (Appointment appointment : appointmentList) {
			// Get appointment date, convert to string, and apply format for export to .csv
			// file.
			appointmentDateString = simpleDateFormat.format(appointment.getAppointmentDate());
			bufferWriter.write(appointment.getAppointmentID() + "," + appointmentDateString + ","
					+ appointment.getAppointmentDescription() + "," + appointment.getAppointmentFirstName() + ","
					+ appointment.getAppointmentLastName());
			// Write new line after each contact.
			bufferWriter.newLine();
		}
		// Close writer channels.
		bufferWriter.close();
		fileWriter.close();
	}

	// Method sorts the appointment list by date.
	public void sortAppointmentListByDate() {
		appointmentList.sort((appointment1, appointment2) -> appointment1.getAppointmentDate()
				.compareTo(appointment2.getAppointmentDate()));
	}

	// Method sorts the appointment list alphabetically by last name.
	public void sortAppointmentListByLastName() {
		appointmentList.sort((appointment1, appointment2) -> appointment1.getAppointmentLastName()
				.compareTo(appointment2.getAppointmentLastName()));
	}

	// Method sorts the appointment list numerically by ID number
	public void sortAppointmentListByID() {
		appointmentList.sort((appointment1, appointment2) -> appointment1.getAppointmentID()
				.compareTo(appointment2.getAppointmentID()));
	}

	// Method searches ArrayList for an appointment using the appointment Id.
	// Returns true if found false if not
	public boolean searchList(String appointmentID) {
		for (Appointment appointment : appointmentList) {
			if (appointment.getAppointmentID().equals(appointmentID)) {
				return true;
			}
		}
		return false;
	}

	// Method to add appointment. Throws exception if appointment Id is already in
	// the list.
	public void addAppointment(Appointment appointment) {
		if (appointmentList.contains(appointment)) {
			throw new IllegalArgumentException("Invalid appointment info");
		} else {
			appointmentList.add(appointment);
		}
	}

	// Method to delete appointment. Throws exception if appointment Id is not
	// found.
	public void deleteAppointment(String appointmentID) {
		Boolean appointmentFound = false;
		Appointment temporaryAppointmentData = null;
		for (Appointment appointment : appointmentList) {
			// If appointment id matches copy appointment data and exit loop.
			if (appointment.getAppointmentID().equalsIgnoreCase(appointmentID)) {
				appointmentFound = true;
				temporaryAppointmentData = appointment;
				break;
			}
		}
		// If the appointment is found remove from list else throw exception.
		if (appointmentFound) {
			appointmentList.remove(temporaryAppointmentData);
		} else {
			throw new IllegalArgumentException("APPOINTMENT NOT FOUND");
		}
	}

	// Method to update appointment date. Throws exception if appointment Id is not
	// found.
	public void updateAppointmentDate(String appointmentID, Date appointmentDate) {
		if (searchList(appointmentID)) {
			for (Appointment appointment : appointmentList) {
				if (appointment.getAppointmentID().equals(appointmentID)) {
					appointment.setAppointmentDate(appointmentDate);
				}
			}
		} else {
			throw new IllegalArgumentException("Invalid ID");
		}
	}

	// Method to update appointment description. Throws exception if appointment Id
	// is not found.
	public void updateAppointmentDescription(String appointmentID, String appointmentDescription) {
		if (searchList(appointmentID)) {
			for (Appointment appointment : appointmentList) {
				if (appointment.getAppointmentID().equals(appointmentID)) {
					appointment.setAppointmentDescription(appointmentDescription);
				}
			}
		} else {
			throw new IllegalArgumentException("Invalid ID");
		}
	}

	// Method prints the appointment list for provided contact.
	public void printAppointmentList(String contactFirstName, String contactLastName) {
		// Index used to determine if no appointments exist for input contact.
		int index = 0;
		// If appointment list is empty throw exception.
		if (appointmentList.isEmpty()) {
			throw new IllegalArgumentException("NO APPOINTMENTS FOUND");
		}
		// If appointment list is not empty sort the appointment list alphabetically by
		// date and print the appointments that match the provided contact.
		else {
			// Create simple date format object to convert date to string and apply format.
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
			// String variable to hold date as string for printing in desired format.
			String timeString;
			// Sort the appointment list by date.
			sortAppointmentListByDate();
			for (Appointment appointment : appointmentList) {
				timeString = simpleDateFormat.format(appointment.getAppointmentDate());
				if (appointment.getAppointmentLastName().equalsIgnoreCase(contactLastName)
						&& appointment.getAppointmentFirstName().equalsIgnoreCase(contactFirstName)) {
					System.out.println(String.format("%-12s", appointment.getAppointmentID()) + " " + String.format("%-13s", timeString) +
							appointment.getAppointmentDescription());
					index++;
				}
			}
			// If no matching appointments found for input contact print message.
			if (index == 0) {
				System.out.println("NO APPOINTMENTS FOR " + contactLastName + ", " + contactFirstName + " FOUND");
			}
		}
	}

	// Method returns next available appointment ID number.
	public String getNextAppointmentID() {
		// If the list contains no appointments, use the first possible ID number.
		if (appointmentList.isEmpty()) {
			return "1000000001";
		}
		// Else sort the list by appointment ID number and add one. Convert string to
		// long for addition and back to string for return.
		else {
			sortAppointmentListByID();
			return String
					.valueOf(Long.parseLong(appointmentList.get(appointmentList.size() - 1).getAppointmentID()) + 1);
		}
	}
}
