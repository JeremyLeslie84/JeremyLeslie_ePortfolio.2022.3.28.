/*
 * Grand Strand System - Contact class.
 * Developed by Jeremy Leslie 11/15/21.
 * Contact class implements:
 * -Contact variables
 * -Setter and getter methods for the Contacts class.
 */

package ContactService;

public class Contact {
	
	// Class variables.
	String contactID;
	String contactFirstName;
	String contactLastName;
	String contactPhoneNumber;
	String contactStreetAddress;
	String contactCity;
	String contactState;
	String contactZIP;
	
	// Contact object constructor.
	public Contact(String contactID, String contactFirstName, String contactLastName, String contactPhoneNumber, String contactStreetAddress,
			String contactCity, String contactState, String contactZIP) {
		
		// Check if contact Id meets input criteria, if not throw exception error.
		if (contactID == null || contactID.length() != 10 || !checkStringIsNumeric(contactID)) {		
			throw new IllegalArgumentException("Invalid ID");
		}
		
		// Check if first name meets input criteria, if not throw exception error.
		if (contactFirstName == null || contactFirstName.length() > 12) {
			throw new IllegalArgumentException("Invalid first name");
		}
		
		// Check if last name meets input criteria, if not throw exception error.
		if (contactLastName == null || contactLastName.length() > 12) {
			throw new IllegalArgumentException("Invalid last name");
		}
		
		// Check if phone # meets input criteria, if not throw exception error.
		if (contactPhoneNumber == null || contactPhoneNumber.length() != 10 || !checkStringIsNumeric(contactPhoneNumber)) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		
		// Check if street address meets input criteria, if not throw exception error.
		if (contactStreetAddress == null || contactStreetAddress.length() > 30) {
			throw new IllegalArgumentException("Invalid street address");
		}
		
		// Check if city meets input criteria, if not throw exception error.
		if (contactCity == null || contactCity.length() > 15) {
			throw new IllegalArgumentException("Invalid city");
		}
		
		// Check if state meets input criteria, if not throw exception error.
		if (contactState == null || contactState.length() != 2) {
			throw new IllegalArgumentException("Invalid state");
		}
		
		// Check if ZIP meets input criteria, if not throw exception error.
		if (contactZIP == null || contactZIP.length() < 4 || contactZIP.length() > 5 || !checkStringIsNumeric(contactZIP)) {
			throw new IllegalArgumentException("Invalid ZIP");
		}

		// Set the current contact object variables.
		this.contactID = contactID;
		this.contactFirstName = contactFirstName;
		this.contactLastName = contactLastName;
		this.contactPhoneNumber = contactPhoneNumber;
		this.contactStreetAddress = contactStreetAddress;
		this.contactCity = contactCity;
		this.contactState = contactState;
		this.contactZIP = contactZIP;
	}
	 
	// Setter methods for the contact class.
	public void setContactFirstName(String contactFirstName) {
		// Check if contact first name meets input criteria, if not throw exception error.
		if(!contactFirstName.isEmpty() && contactFirstName.length() <= 20) {
			this.contactFirstName = contactFirstName;
		}
		else {
			throw new IllegalArgumentException("Invalid First Name");
		}
	}
	
	public void setContactLastName(String contactLastName) {
		// Check if contact last name meets input criteria, if not throw exception error.
		if(!contactLastName.isEmpty() && contactLastName.length() <= 20) {
			this.contactLastName = contactLastName;
		}
		else {
			throw new IllegalArgumentException("Invalid Last Name");
		}
	}
	
	public void setContactPhoneNumber(String contactPhoneNumber) {
		// Check if contact phone number meets input criteria, if not throw exception error.
		if(contactPhoneNumber.length() == 10 && checkStringIsNumeric(contactPhoneNumber)) {
			this.contactPhoneNumber = contactPhoneNumber;
		}
		else {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
	}
	
	public void setContactStreetAddress(String contactStreetAddress) {
		// Check if contact street address meets input criteria, if not throw exception error.
		if (!contactStreetAddress.isBlank() && contactStreetAddress.length() <= 30) {
			this.contactStreetAddress = contactStreetAddress;
		}
		else {
			throw new IllegalArgumentException("Invalid Street Address");
		}
	}
	
	public void setContactCity(String contactCity) {
		// Check if contact city meets input criteria, if not throw exception error.
		if (!contactCity.isBlank() && contactCity.length() <= 15) {
			this.contactCity = contactCity;
		}
		else {
			throw new IllegalArgumentException("Invalid City");
		}
	}
	
	public void setContactState(String contactState) {
		// Check if contact state meets input criteria, if not throw exception error.
		if (contactState.length() == 2) {
			this.contactState = contactState;
		}
		else {
			throw new IllegalArgumentException("Invalid State");
		}
	}
	
	public void setContactZIP(String contactZIP) {
		// Check if contact ZIP meets input criteria, if not throw exception error.
		if(contactZIP.length() == 5 && checkStringIsNumeric(contactZIP)) {
			this.contactZIP = contactZIP;
		}
		else {
			throw new IllegalArgumentException("Invalid ZIP");
		}		
	}
		
	// Getter methods for the contact class.
	public String getContactID() {
		return contactID;
	}
		
	public String getContactFirstName() {
		return contactFirstName;
	}
	
	public String getContactLastName() {
		return contactLastName;
	}

	public String getContactPhoneNumber() {
		return contactPhoneNumber;
	}
	
	public String getContactStreetAddress() {
		return contactStreetAddress;
	}	
	
	public String getContactCity() {
		return contactCity;
	}	
	
	public String getContactState() {
		return contactState;
	}	

	public String getContactZIP() {
		return contactZIP;
	}	
	
	// Method checks string format. If it contains any non-numeric characters or spaces a number format exception will be thrown.
	private boolean checkStringIsNumeric(String checkString) {
		try {
			Long.parseLong(checkString);
			return true;
		} catch (NumberFormatException numberFormatException) {
			return false;
		}
	}
}
