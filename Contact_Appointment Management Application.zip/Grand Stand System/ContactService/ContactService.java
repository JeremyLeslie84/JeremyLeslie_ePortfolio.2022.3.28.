/*
 * Grand Strand System - ContactService class.
 * Developed by Jeremy Leslie 11/15/21.
 * ContactService class implements:
 *  -Contacts file import from .csv.
 *  -Contacts file export to .csv.
 *  -CRUD functionality for the Contacts class.
 */
package ContactService;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class ContactService {
	// Declare ArrayList to store contacts.
	ArrayList<Contact> contactList = new ArrayList<>();

	// Method reads contact list from csv file.
	public void readContactsFromDisk() throws IOException {
		// Define the path to the source file.
		Path pathToFile = Paths
				.get("C:\\Users\\Keebler21084\\git\\Grand Strand System\\Grand Strand System\\contact_list.csv");
		// Create a buffer reader object to read file.
		BufferedReader bufferReader = Files.newBufferedReader(pathToFile);
		// Read the next line of the loaded file into the buffer.
		String line = bufferReader.readLine();
		// Index used to ignore the first line of the file (header).
		int index = 0;
		// Loop until next line is null.
		while (line != null) {
			// If the current line in the buffer is the header.
			if (index == 0) {
				index++;
				// Read the next line of the file into the buffer.
				line = bufferReader.readLine();
				// If the current line in the buffer is not the header.
			} else {
				// Create a string array to store parsed values from line using the comma as a
				// separator.
				String[] fileValues = line.split(",");
				// Create a new contact object using fileValues array containing parsed file
				// values.
				Contact contact = new Contact(fileValues[0].toUpperCase(), fileValues[1].toUpperCase(),
						fileValues[2].toUpperCase(), fileValues[3].toUpperCase(), fileValues[4].toUpperCase(),
						fileValues[5].toUpperCase(), fileValues[6].toUpperCase(), fileValues[7].toUpperCase());
				// Add contact to ArrayList.
				addContact(contact);
				// Read the next line of the file into the buffer.
				line = bufferReader.readLine();
			}
		}
	}

	// Method saves contact list as csv file.
	public void writeContactsToDisk() throws IOException {
		// Create a new file.
		File file = new File("contact_list.csv");
		// Create file writer and buffer writer objects to write file.
		FileWriter fileWriter = new FileWriter(file);
		BufferedWriter bufferWriter = new BufferedWriter(fileWriter);
		// Write header to file.
		bufferWriter.write("ContactID,FirstName,LastName,PhoneNumber,StreetAddress,City,State,Zip");
		// Write a new line after the header.
		bufferWriter.newLine();
		// Writer each contact in array list to file.
		for (Contact contact : contactList) {
			bufferWriter.write(contact.getContactID() + "," + contact.getContactFirstName() + ","
					+ contact.getContactLastName() + "," + contact.getContactPhoneNumber() + ","
					+ contact.getContactStreetAddress() + "," + contact.getContactCity() + ","
					+ contact.getContactState() + "," + contact.getContactZIP());
			// Write new line after each contact.
			bufferWriter.newLine();
		}
		// Close writer channels.
		bufferWriter.close();
		fileWriter.close();
	}

	// Method sorts the contact list alphabetically by last name.
	public void sortContactListByLastName() {
		contactList
				.sort((contact1, contact2) -> contact1.getContactLastName().compareTo(contact2.getContactLastName()));
	}

	// Method sorts the contact list numerically by ID number
	public void sortContactListByID() {
		contactList.sort((contact1, contact2) -> contact1.getContactID().compareTo(contact2.getContactID()));
	}

	// Method searches ArrayList for a contact using the contact Id. Returns true if
	// found, false if not found
	public boolean searchContactList(String contactID) {
		for (Contact contact : contactList) {
			if (contact.getContactID().equals(contactID)) {
				return true;
			}
		}
		return false;
	}

	// Method to add contact. Throws exception if contact Id is already in the list
	public void addContact(Contact contact) {
		if (contactList.contains(contact)) {
			throw new IllegalArgumentException("INVALID CONTACT INFO");
		} else {
			contactList.add(contact);
		}
	}

	// Method searches contact list using first name and last name and deletes
	// contact if found.
	public void deleteContact(String contactLastName, String contactFirstName) {
		Boolean contactFound = false;
		Contact contact_remove = null;
		for (Contact contact : contactList) {
			// If first name and last name match copy contact data and exit loop.
			if (contact.getContactLastName().equalsIgnoreCase(contactLastName)
					&& contact.getContactFirstName().equalsIgnoreCase(contactFirstName)) {
				contactFound = true;
				contact_remove = contact;
				break;
			}
		}
		// If the contact is found remove from list else throw exception.
		if (contactFound) {
			contactList.remove(contact_remove);
		} else {
			throw new IllegalArgumentException("CONTACT NOT FOUND");
		}
	}

	// Method updates first name of contact using contact Id. Throws exception if
	// contact Id is not found
	public void updateContactFirstName(String contactID, String updatedContactFirstName) {
		if (searchContactList(contactID)) {
			for (Contact contact : contactList) {
				if (contact.getContactID().equals(contactID)) {
					contact.setContactFirstName(updatedContactFirstName);
				}
			}
		} else {
			throw new IllegalArgumentException("INVALID ID");
		}
	}

	// Method updates last name of contact using contact Id. Throws exception if
	// contact Id is not found
	public void updateContactLastName(String contactID, String updatedContactLastName) {
		if (searchContactList(contactID)) {
			for (Contact contact : contactList) {
				if (contact.getContactID().equals(contactID)) {
					contact.setContactLastName(updatedContactLastName);
				}
			}
		} else {
			throw new IllegalArgumentException("INVALID ID 2NTACT LAST NAME");
		}
	}

	// Method updates phone # of contact using contact Id. Throws exception if
	// contact Id is not found
	public void updateContactPhoneNumber(String contactID, String updatedContactPhoneNumber) {
		if (searchContactList(contactID)) {
			for (Contact contact : contactList) {
				if (contact.getContactID().equals(contactID)) {
					contact.setContactPhoneNumber(updatedContactPhoneNumber);
				}
			}
		} else {
			throw new IllegalArgumentException("INVALID ID - CONTACT PHONE NUMBER");
		}
	}

	// Method updates street address of contact using contact Id. Throws exception
	// if contact Id is not found
	public void updateContactStreetAddress(String contactID, String updatedContactStreetAddress) {
		if (searchContactList(contactID)) {
			for (Contact contact : contactList) {
				if (contact.getContactID().equals(contactID)) {
					contact.setContactStreetAddress(updatedContactStreetAddress);
				}
			}
		} else {
			throw new IllegalArgumentException("INVALID ID - CONTACT STREET ADDRESS");
		}
	}

	// Method updates city of contact using contact Id. Throws exception if contact
	// Id is not found
	public void updateContactCity(String contactID, String updatedContactCity) {
		if (searchContactList(contactID)) {
			for (Contact contact : contactList) {
				if (contact.getContactID().equals(contactID)) {
					contact.setContactCity(updatedContactCity);
				}
			}
		} else {
			throw new IllegalArgumentException("INVALID ID - CONTACT CITY");
		}
	}

	// Method updates state of contact using contact Id. Throws exception if contact
	// Id is not found
	public void updateContactState(String contactID, String updatedContactState) {
		if (searchContactList(contactID)) {
			for (Contact contact : contactList) {
				if (contact.getContactID().equals(contactID)) {
					contact.setContactState(updatedContactState);
				}
			}
		} else {
			throw new IllegalArgumentException("INVALID ID - CONTACT STATE");
		}
	}

	// Method updates ZIP of contact using contact Id. Throws exception if contact
	// Id is not found
	public void updateContactZIP(String contactID, String updatedContactZIP) {
		if (searchContactList(contactID)) {
			for (Contact contact : contactList) {
				if (contact.getContactID().equals(contactID)) {
					contact.setContactZIP(updatedContactZIP);
				}
			}
		} else {
			throw new IllegalArgumentException("INVALID ID");
		}
	}

	// Method prints the contact list ordered alphabetically by last name.
	public void printContactListByLastName() {
		// If contact list is empty throw exception.
		if (contactList.isEmpty()) {
			throw new IllegalArgumentException("NO CONTACTS FOUND");
		}
		// If contact list is not empty sort the contact list alphabetically by last
		// name and print the contact list.
		else {			
			// Sort the contact list by last name.
			sortContactListByLastName();
			for (Contact contact : contactList) {
				System.out.println(String.format("%-12s", contact.getContactLastName()) + String.format("%-12s", contact.getContactFirstName()) + contact.getContactID());
			}
			
		}
	}

	// Method searches contact list using first name and last name and prints
	// contact info if found.
	public void printContactInfoByName(String contactFirstName, String contactLastName) {
		Boolean contactFound = false;
		for (Contact contact : contactList) {
			// If first name and last name match print contact info.
			if (contact.getContactLastName().equalsIgnoreCase(contactLastName)
					&& contact.getContactFirstName().equalsIgnoreCase(contactFirstName)) {
				System.out.println("ID: " + contact.getContactID());
				System.out.println("FIRST NAME: " + contact.getContactFirstName());
				System.out.println("LAST NAME: " + contact.getContactLastName());
				System.out.println("PHONE NUMBER: " + contact.getContactPhoneNumber());
				System.out.println("STREET ADDRESS: " + contact.getContactStreetAddress());
				System.out.println("CITY: " + contact.getContactCity());
				System.out.println("STATE: " + contact.getContactState());
				System.out.println("ZIP: " + contact.getContactZIP());
				contactFound = true;
				break;
			}
		}
		// If the contact is not found throw exception.
		if (!contactFound) {
			throw new IllegalArgumentException("CONTACT NOT FOUND");
		}
	}

	// Method returns next available contact ID number.
	public String getNextContactID() {
		// If the list contains no contacts, use the first possible ID number.
		if (contactList.isEmpty()) {
			return "1000000001";
		}
		// Else sort the list by contact ID number and add one. Convert string to
		// long for addition and back to string for return.
		else {
			sortContactListByID();
			return String.valueOf(Long.parseLong(contactList.get(contactList.size() - 1).getContactID()) + 1);
		}
	}

	// Method returns contact ID if found and string if not found.
	public String getContactID(String contactLastName, String contactFirstName) {
		for (Contact contact : contactList) {
			if (contact.getContactLastName().equalsIgnoreCase(contactLastName)
					&& contact.getContactFirstName().equalsIgnoreCase(contactFirstName)) {
				return contact.getContactID();
			}
		}
		return "ID Not Found";
	}
}