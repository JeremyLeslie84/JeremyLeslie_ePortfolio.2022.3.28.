/*
 * Grand Strand System - Main class.
 * Developed by Jeremy Leslie 11/15/21.
 * Main Class Implements:
 * -Data management tasks for the Contacts and Appointments classes.
 */

package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import AppointmentService.Appointment;
import AppointmentService.AppointmentService;
import ContactService.Contact;
import ContactService.ContactService;

public class Main {
	// Global variables for the main class.
	static String contactFirstName;
	static String contactLastName;

	// Buffer reader object to read user inputs.
	static BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));

	public static void main(String[] args) throws IOException, ParseException {
		// Local variables for main class.
		String userInput = "";
		String contactPhoneNumber;
		String contactStreetAddress;
		String contactCity;
		String contactState;
		String contactZIP;
		String appointmentDescription;
		String appointmentID;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date appointmentDate = new Date();

		// Create new contactService object to manage contacts.
		ContactService contactService = new ContactService();
		// Create new appointmentService object to manage appointments.
		AppointmentService appointmentService = new AppointmentService();
		// Load contact data from .csv file.
		contactService.readContactsFromDisk();
		// Load appointment data from .csv file.
		appointmentService.readAppointmentsFromDisk();
		// Print welcome message.
		System.out.println("WELCOME TO THE GRAND STRAND APPOINTMENT MANAGMENT SYSTEM");
		// Top level user input loop. Loop until user enters 1.
		while (!userInput.equals("1")) {
			System.out.print("INPUT OPTIONS:\n1 - TO EXIT\n2 - TO SERVICE CONTACTS\n3 - TO SERVICE APPOINTMENTS\n-> ");
			userInput = bufferReader.readLine().toUpperCase();
			switch (userInput) {
			// Exit case.
			case "1":
				System.out.println("Exiting...");
				break;
			// Service Contact case.
			case "2":
				userInput = "";
				// User input loop for service contact menu. Loop until user enters X.
				while (!userInput.equalsIgnoreCase("X")) {
					System.out.print(
							"SERVICE CONTACTS - INPUT OPTIONS:\nX - TO GO BACK\n1 - TO PRINT CONTACT LIST BY LAST NAME\n2 - TO CREATE NEW CONTACT"
									+ "\n3 - TO DELETE EXISTING CONTACT\n4 - TO UPDATE FIRST NAME\n5 - TO UPDATE LAST NAME"
									+ "\n6 - TO UPDATE STREET ADDRESS\n7 - TO UPDATE CITY\n8 - TO UPDATE STATE\n9 - TO UPDATE ZIP\n-> ");
					userInput = bufferReader.readLine().toUpperCase();
					switch (userInput) {
					// Exit case.
					case "X":
						break;
					// Print contact list case.
					case "1":
						System.out.println("CONTACT LIST:");
						System.out.println("LAST NAME:  FIRST NAME: ID:");
						contactService.printContactListByLastName();
						break;
					// Create new contact case. If contact already in list print error else add
					// contact to list.
					case "2":
						System.out.println("CREATE NEW CONTACT:");
						getContactName();
						String contactID = contactService.getContactID(contactLastName, contactFirstName);
						// If the contact is found in list print message.
						if (contactService.searchContactList(contactID)) {
							System.out.println("CONTACT ALREADY EXISTS");
						// If the contact is not found read inputs from buffer and create new contact.
						} else {
							System.out.println("ENTER PHONE # (MUST BE 10 CHARACTERS - NO DASHES) -> ");
							contactPhoneNumber = bufferReader.readLine().toUpperCase();
							System.out.println("ENTER STREET ADDRESS (UP TO 50 CHARACTERS) -> ");
							contactStreetAddress = bufferReader.readLine().toUpperCase();
							System.out.println("ENTER CITY (UP TO 30 CHARACTERS) -> ");
							contactCity = bufferReader.readLine().toUpperCase();
							System.out.println("ENTER STATE (MUST BE 2 CHARACTERS) -> ");
							contactState = bufferReader.readLine().toUpperCase();
							System.out.println("ENTER ZIP (MUST BE 5 CHARACTERS) -> ");
							contactZIP = bufferReader.readLine().toUpperCase();
							Contact contact_add = new Contact(contactService.getNextContactID(), contactFirstName,
									contactLastName, contactPhoneNumber, contactStreetAddress, contactCity,
									contactState, contactZIP);
							contactService.addContact(contact_add);
						}
						break;
					// Delete existing contact case.
					case "3":
						System.out.println("DELETE CONTACT:");
						getContactName();
						contactService.deleteContact(contactLastName, contactFirstName);
						break;
					// Update first name case.
					case "4":
						System.out.println("UPDATE CONTACT FIRST NAME:");
						getContactName();
						System.out.println("ENTER NEW FIRST NAME");
						String updatedContactFirstName = bufferReader.readLine().toUpperCase();
						;
						contactService.updateContactFirstName(
								contactService.getContactID(contactLastName, contactFirstName),
								updatedContactFirstName);
						break;
					// Update last name case.
					case "5":
						System.out.println("UPDATE CONTACT LAST NAME:");
						getContactName();
						System.out.println("ENTER NEW LAST NAME");
						String updatedContactLastName = bufferReader.readLine().toUpperCase();
						contactService.updateContactLastName(
								contactService.getContactID(contactLastName, contactFirstName), updatedContactLastName);
						break;
					// Update street address case.
					case "6":
						System.out.println("UPDATE CONTACT STREET ADDRESS:");
						getContactName();
						System.out.println("ENTER NEW STREET ADDRESSS");
						String updatedStreetAddress = bufferReader.readLine().toUpperCase();
						;
						contactService.updateContactStreetAddress(
								contactService.getContactID(contactLastName, contactFirstName), updatedStreetAddress);
						break;
					// Update city case.
					case "7":
						System.out.println("UPDATE CONTACT CITY:");
						getContactName();
						System.out.println("ENTER NEW CITY");
						String updatedCity = bufferReader.readLine().toUpperCase();
						;
						contactService.updateContactCity(contactService.getContactID(contactLastName, contactFirstName),
								updatedCity);
						break;
					// Update state case.
					case "8":
						System.out.println("UPDATE CONTACT STATE:");
						getContactName();
						System.out.println("ENTER NEW STATE");
						String updatedState = bufferReader.readLine().toUpperCase();
						;
						contactService.updateContactState(
								contactService.getContactID(contactLastName, contactFirstName), updatedState);
						break;
					// Update ZIP case.
					case "9":
						System.out.println("UPDATE CONTACT ZIP:");
						getContactName();
						System.out.println("ENTER NEW ZIP");
						String updatedZIP = bufferReader.readLine().toUpperCase();
						;
						contactService.updateContactZIP(contactService.getContactID(contactLastName, contactFirstName),
								updatedZIP);
						break;
					// Default case for non-defined inputs.
					default:
						System.out.println("INVALID INPUT");
						break;
					}
					// Sort and write (update) contact list to disk.
					contactService.sortContactListByID();
					contactService.writeContactsToDisk();
				}
				break;
			// Service Appointment case.
			case "3":
				userInput = "";
				// User input loop for service appointment menu. Loop until user enters X.
				while (!userInput.equalsIgnoreCase("X")) {
					System.out.print(
							"SERVICE APPOINTMENTS - INPUT OPTIONS:\nX - TO GO BACK\n1 - TO PRINT APPOINTMENT LIST\n2 - TO CREATE NEW APPOINTMENT"
									+ "\n3 - TO DELETE EXISTING APPOINTMENT\n4 - TO UPDATE APPOINTMENT DATE\n5 - TO UPDATE APPOINTMENT DESCRIPTION\n-> ");
					userInput = bufferReader.readLine().toUpperCase();

					switch (userInput) {
					// Exit case.
					case "X":
						break;
					// Print appointment list case.
					case "1":
						getContactName();
						System.out.println("APPOINTMENTS FOR: " + contactLastName + ", " + contactFirstName);
						System.out.println("ID           DATE:        DESCRIPTION:");
						appointmentService.printAppointmentList(contactFirstName, contactLastName);
						break;
					// Create new appointment case.
					case "2":
						System.out.println("ADD APPOINTMENT:");
						getContactName();
						// If the contact is found in list print message.
						String contactID = contactService.getContactID(contactLastName, contactFirstName);
						if (!contactService.searchContactList(contactID)) {
							System.out.println("CONTACT DOES NOT EXISTS");
						// If the appointment is not found read inputs from buffer and create new
						// appointment.
						} else {
							System.out.println("ENTER DATE(MM/DD/YYYY) -> ");
							appointmentDate = simpleDateFormat.parse(bufferReader.readLine().toUpperCase());
							System.out.println("APPOINTMENT DESCRIPTION (UP TO 50 CHARACTERS) -> ");
							appointmentDescription = bufferReader.readLine().toUpperCase();
							Appointment appointment_add = new Appointment(appointmentService.getNextAppointmentID(),
									appointmentDate, appointmentDescription, contactFirstName, contactLastName);
							appointmentService.addAppointment(appointment_add);
						}
						break;
					// Delete existing appointment case.
					case "3":
						System.out.println("DELETE APPOINTMENT:");
						System.out.println("ENTER APPOINTMENT ID -> ");
						appointmentService.deleteAppointment(bufferReader.readLine().toUpperCase());
						break;
					// Update appointment date case.
					case "4":
						System.out.println("UPDATE APPOINTMENT DATE:");
						System.out.println("ENTER APPOINTMENT ID -> ");
						appointmentID = bufferReader.readLine().toUpperCase();
						System.out.println("ENTER DATE(MM/DD/YYYY) -> ");
						appointmentDate = simpleDateFormat.parse(bufferReader.readLine().toUpperCase());
						appointmentService.updateAppointmentDate(appointmentID, appointmentDate);
						break;
					// Update appointment description case.
					case "5":
						System.out.println("UPDATE APPOINTMENT DESCRIPTION:");
						System.out.println("ENTER APPOINTMENT ID -> ");
						appointmentID = bufferReader.readLine().toUpperCase();
						System.out.println("ENTER NEW DESCRIPTION -> ");
						appointmentDescription = bufferReader.readLine().toUpperCase();
						appointmentService.updateAppointmentDescription(appointmentID, appointmentDescription);
						break;
					default:
						System.out.println("INVALID INPUT");
						break;
					}
					// Sort and write (update) appointment list to disk.
					appointmentService.sortAppointmentListByID();
					appointmentService.writeAppointmentsToDisk();
				}
				break;
			default:
				System.out.println("INVALID INPUT");
				break;
			}
		}
	}

	// Method reads user name from buffer.
	private static void getContactName() throws IOException {
		System.out.println("ENTER FIRST NAME (UP TO 20 CHARACTERS) -> ");
		contactFirstName = bufferReader.readLine().toUpperCase();
		System.out.println("ENTER LAST NAME (UP TO 20 CHARACTERS) -> ");
		contactLastName = bufferReader.readLine().toUpperCase();
	}
}
