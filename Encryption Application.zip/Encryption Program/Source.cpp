/*
User validation using XOR encryption.
Imports user name, password, and user data from text file.
Decrypts import data, parses into vector, then compares against user inputs to authenticate user.
*/

#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <conio.h>

using namespace std;

// Method shifts input string by key value to either encrypt or decrypt string data.
string encrypt_decrypt(string& input_data, string& key) {
    // Characater array to store key value.
    char key_character[2];
    // If key size matches expected value perform shift operation.
    if (key.size() == 1) {
        if (input_data.size() >= 1) {
            // Copy string to character array for shift operation.
            strcpy_s(key_character, key.c_str());;
            // Create a copy of the input string.
            string shifted_data = input_data;
            // Loop through each character in input string copying shifted value to the return string at the same index.
            for (int i = 0; i < input_data.size(); i++) {
                shifted_data[i] = input_data[i] ^ key_character[0];
            }
            return shifted_data;
        }
        else{
            cout << "INVALID USER DATA" << endl;
            return "";
        }
    }
    // If the key size doesn't match the expected value print message and return null string
    else {
        cout << "INVALID KEY" << endl;
        return "";
    }
}

// Method reads file from disk using ifstream.
string read_file(const string& file_name) {
    string return_text;

    try {
        ifstream file_input(file_name, ios::in);
        if (file_input.is_open()) {
            string line;
            // Loop through each line of file and append each line to return string.
            while (getline(file_input, line)) {
                return_text.append(line);
            }
            // Close the file.
            file_input.close();
        }
        else {
            // If the file fails to open print message.
            cout << file_name << " LOAD FAILED" << endl;
            return "";
        }
        return return_text;
    }
    catch (std::ifstream::failure e) {
        std::cerr << "Exception opening/reading/closing file\n";
    }
}

// Method takes string input and parses into vector using comma separator.
vector<string> parsed_data(string& data_file) {

    stringstream stringstream(data_file);
    vector<string> user_vector;
    string sub_string;

    // While the stringstream hasn't found new line or end of file.
    while (stringstream.good()) {
        // Get the next substring from stringstream using comma separator and push to vector.
        getline(stringstream, sub_string, ',');
        user_vector.push_back(sub_string);
    }
    return user_vector;
}

// Method checks vector elements against user inputs to authenticate user.
int user_authentication(vector<string> user_data, string user_name, string password) {
    // If first element of vector (user name) matches user name input.
    if (user_data[0].compare(user_name) == 0) {
        // If the second element of vector (password) matches user password input.
        if (user_data[1].compare(password) == 0) {
            return 0;
        }
        else {
            return -1;
        }
    }
    else {
        return -1;
    }
}

int main(int argc, const char* argv[]) {

    string user_name;
    string password;
    char password_array[20]{};
    int i = 0;
    char input_character;
    cout << "ENTER USER NAME: ";
    cin >> user_name;
    cout << "ENTER PASSWORD: ";

    // Obscure user input for password. Check user input until length equals 20 or enter key is read.
    for (int i = 0; i < 20; i++) {
        input_character = _getch();
        if (input_character == '\r') {
            break;
        }
        // If user input is not enter key add input character to password array.
        else {
            password_array[i] = input_character;
            cout << "*";
            password += password_array[i];
        }
    }
    cout << endl;

    // Reads the key value from file.
    std::string key_string = read_file("key.txt");
 
    // Read encrypted data file.
    string encrypted_data = read_file("encrypted_data_file.txt");
    // decrypt data file.
    string decrypted_data = encrypt_decrypt(encrypted_data, key_string);

    // Parse input data using comma separater and store as vector.
    vector<string> user_vector = parsed_data(decrypted_data);
    // If vector size equals the expected value.
    if (user_vector.size() == 3) {
        // Check user login credentials.
        if (user_authentication(user_vector, user_name, password) == 0) {
            cout << "AUTHENTICATION SUCCESSFUL" << endl;
            // If both data files succeeded print data.
            cout << "ENCRYPTED DATA: " + encrypted_data << endl;
            // Output to show decrypted string.
            cout << "DECRYPTED DATA: " + decrypted_data << endl;
            // TODO. RETURN VALUE TO CALLING PROCESS CONFIRMING USER AUTHENTICATION.
        }
        // If authentication fails print message.
        else {
            cout << "AUTHENTICATION FAILED" << endl;
            // TODO. RETURN VALUE TO CALLING PROCESS DENYING USER AUTHENTICATION.
        }
    }
    return 0;
}
